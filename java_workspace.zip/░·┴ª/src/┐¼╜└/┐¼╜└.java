package 연습;

public class 연습 {
	
	public static void main(String[] args) {
		
	    /* 1. 변수 생성 */
	    int math = 96;
	    int science = 88;
	    int eng = 76;
	    /* 2. 결과 출력 */
	    System.out.println("수학: " + math);
	    System.out.println("과학: " + science);
	    System.out.println("영어: " + eng);
	  
	 /*   
	    Tom은 아침에 샌드위치를 팔아 용돈벌이를 시작했다. 이번 한 주간 수입은 다음과 같다.

	    월: $ 8.62
	    화: $ 10.23
	    수: $ 12.48
	    목: $ 7.82
	    금: $ 9.54
	    월요일 부터 금요일까지 얻은 총 수입은 얼마인지 출력하시오.
	*/
	    
	    double 월 = 8.62;
	    double 화 = 10.23;
	    double 수 = 12.48;
	    double 목 = 7.82;
	    double 금 = 9.54;    
	    /* 2. 총합 계산 */
	    double total = 월+화+수+목+금;
	  
	    /* 3. 총합 출력 */
	    
	    System.out.printf("%.2f",total);
	    
//	    System.out.println("$" + total);
//	    
	    
	}

}
