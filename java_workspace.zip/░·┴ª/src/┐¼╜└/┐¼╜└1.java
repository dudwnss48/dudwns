package 연습;

public class 연습1 {
	  public static void main(String[] args) {
		    // 속도(m/s) = 거리(m) / 시간(s)
		    double meter = 100;
		    double sec = 18;

		    // 속도(km/h) = 거리(km) / 시간(h)
		    double sisok = (meter/1000) / (sec/3600);

		    // 결과 출력
		    System.out.printf("%.1fkm/h",sisok);
	}
}	  