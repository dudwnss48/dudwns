package operator;

import java.util.Scanner;

public class ScannerDemo2 {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		/*
		 * 학생이름, 국어점수, 영어점수, 수학점수를 입력받는다.
		 * 출력내용
		 *		학생이름, 국어점수, 영어점수, 수학점수, 총점, 평균 , 합격여부, 장학금지급여부
		 *		* 합격여부는 평균이 60점 이상인 경우만 "예"로 출력 그 외는 "아니오"출력
		 *		* 장학금 지급여부는 평균이 96점 이상인 경우만 "예"로 출력, 그 외는 "아니오" 출력
		 */

		System.out.print("학생이름을 입력하세요:");
		String studentName = scanner.next();
		
		System.out.print("국어점수를 입력하세요:");
		int korScore = scanner.nextInt();
		
		System.out.print("영어점수을 입력하세요:");
		int engScore = scanner.nextInt();

		System.out.print("수학점수을 입력하세요:");
		int mathScore = scanner.nextInt();
		
		int total = (korScore + engScore + mathScore);
		int average = (total)/3;
		String 합격여부 = average >= 60 ? "예" : "아니오";
		String 장학금지급여부 = average >= 96 ? "예" : "아니오";
		

		
		System.out.println();
		System.out.println(studentName);
		System.out.println(korScore);
		System.out.println(engScore);
		System.out.println(mathScore);
		System.out.println(total);
		System.out.println(average);
		System.out.println(합격여부);
		System.out.println(장학금지급여부);
	
		
		

	}

}
