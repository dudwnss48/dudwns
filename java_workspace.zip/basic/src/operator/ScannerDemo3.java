package operator;

import java.util.Scanner;

public class ScannerDemo3 {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		/*
		 * 고객명, 상품명, 가격, 구매수량, 사용포인트를 입력받는다.
		 *  출력내용
		 *  	고객명, 상품명, 가격, 구매수량, 구매가격, 사용포인트, 결제금액, 적립포인트
		 *			* 사용포인트는 고객이 이미 적립한 포인트가 있다고 가정하고, 임의의 값을 입력받는다.
		 *  		* 결제금액은 구매가격에서 포인트 사용량을 제외한 금액이다.
		 *  		* 적립 포인트는 실결제금액의 3%다.
		 */
		System.out.print("고객명을 입력하세요:");
		String 고객명 = scanner.next();
		
		System.out.print("상품명을 입력하세요:");
		String 상품명 = scanner.next();
		
		System.out.print("구매수량을 입력하세요:");
		int 구매수량 = scanner.nextInt();
		
		System.out.print("구매가격을 입력하세요:");
		int 구매가격 = scanner.nextInt();
		
		System.out.print("사용포인트을 입력하세요:");
		int 사용포인트 = scanner.nextInt();
		
		int 결제금액 = 구매수량*구매가격-사용포인트;
		int 적립포인트 = (int)(결제금액*0.03);

		
		System.out.println();
		System.out.println("---------결제내역---------");
		System.out.println("고  객  명:" + 고객명);
		System.out.println("상  품  명:" + 상품명);
		System.out.println("구매  수량:" + 구매수량);
		System.out.println("구매  가격:" + 구매가격);
		System.out.println("사용포인트:" + 사용포인트);
		System.out.println("총결제금액:" + 결제금액);
		System.out.println("적립포인트:" + 적립포인트);

		
		
		
		
		
	}

}
