package Array;

import java.util.Scanner;

public class ArrayDemo9 {
	
	public static void main(String[] args) {
		/*
		 * 숫자를 10개 입력받아서 그 중에 짝수들의 합계만 구해서 출력하기
		 */
		Scanner scanner = new Scanner(System.in);
		
		int total = 0;
		int [] numbers = new int [10];
		
		for (int i=0; i<numbers.length; i++) {
			System.out.print("숫자를 입력하시오: ");
			int num = scanner.nextInt();
			numbers[i] = num;
		  //==>numbers [i] = scanner.nextInt();
		}
		for (int a : numbers) {
			if (a%2==0) {
				total += a;
			}
		}
		System.out.println("입력한 숫자 중 모든 짝수들의 합: " + total);
	}

}
