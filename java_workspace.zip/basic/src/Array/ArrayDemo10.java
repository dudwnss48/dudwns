package Array;

import java.util.Scanner;

public class ArrayDemo10 {
	
	public static void main(String[] args) {
		/*
		 * 숫자를 10개 입력받아서 인접한 두 수의 차이가 가장 많이 나는 숫자를 각각 출력하기
		 */
		Scanner scanner = new Scanner(System.in);
		
		// 배열 생성하기
		
		// 숫자 10개 입력받아서 배열에 담기
		
		// 출력할 값을 담는 변수 만들기
		int [] numbers = new int [10];

		int prev = 0;
		int next = 0;
		int gap = 0;
		
		for (int i=0; i<numbers.length; i++) {
			System.out.print("숫자를 입력하시오: ");
			int num = scanner.nextInt();
			numbers[i] = num;
		}

		for (int i=0 ; i<numbers.length-1 ; i++ ) {
			int tempPrev = numbers[i];
			int tempNext = numbers[i+1];
			int currentGap = Math.abs(numbers[i]-numbers[i+1]);
			if (currentGap>gap) {
				prev = tempPrev;
				next = tempNext;
				gap = currentGap;
			} 
		}
		System.out.println("숫자 1 : " + prev + "\n숫자 2 : " + next + "\n갭 : " + gap);
		
	}

}
