package basic;

/*
 * 다중 행 주석(범위주석)
 *     여러 줄의 코멘트(주석)를 작성할 떄 사용한다.
 * 작성일 : 2020.03.09
 * 작성자 : 권영준
 * 이메일 : dudwnss48@naver.com
 * 내용 : 단일 행/다중 행 주석 연습하기
 */
public class CommentDemo {
	
	public static void main(String[] args) {
		// 단일 행 주석
		
		//표준출력장치에 "Hello, world."를 출력한다.
		System.out.println("Hello, world.");
//		System.out.println("Hello, world.");
//		System.out.println("Hello, world.");
//		System.out.println("Hello, world.");
//		System.out.println("Hello, world.");
//		System.out.println("Hello, world.");
//		System.out.println("Hello, world.");
//		System.out.println("Hello, world.");
				
	}

}
