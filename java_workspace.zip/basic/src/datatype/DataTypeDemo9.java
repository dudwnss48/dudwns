package datatype;

public class DataTypeDemo9 {
	
	public static void main(String[] args) {
		/*
		 * 홍길동 고객은
		 * 		3만원짜리 셔츠 3장
		 * 		10만원짜리 청바지 2장
		 * 		50만원짜리 구두 1켤레를 구매했다.
		 * 홍길동 고객의 총 구매금액을 출력하기
		 * 해당 사이트에서는 구매금액의 3%를 포인트로 적립시킨다.(포인트는 정수값만 사용한다.)
		 * 홍길동 고객이 이번 주문에서 적립한 포인트를 출력하기
		 */
		int 셔츠가격 = 30000;
		int 셔츠갯수 = 3;
		int 청바지가격 = 100000;
		int 청바지갯수 = 2;
		int 구두가격 = 500000;
		int 구두켤레수 = 1;
		
		int 총구매금액 = 셔츠갯수*셔츠가격 + 청바지갯수*청바지가격 + 구두켤레수*구두가격 ;
		
		int point = 3;
		
		System.out.println("홍길동 고객님의 총 구매금액 : " + 총구매금액 + "원");
		System.out.println("홍길동 고객님의 적립 point : " + (총구매금액/100*point) + "점");
		
	
	}

}
