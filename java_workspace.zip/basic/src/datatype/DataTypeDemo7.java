
package datatype;

public class DataTypeDemo7 {
	
	public static void main(String[] args) {
		// 변수 활용하기
		/*
		 * 본인의 이름, 전화번호, 이메일, 나이, 키, 몸무게, 혈액형, 결혼여부을
		 * 저장하는 변수를 선언하고 해당값을 각 변수에 저장하기
		 * 
		 * 각 변수에 저장된 값을 출력하기
		 */
		String 이름 = "권영준";
		String 전화번호 = "010-2773-1939";
		String 이메일 = "dudwnss48@naver.com";
		int 나이 = 27;
		double 키 = 177.8;
		double 몸무게 = 100.0;
		String 혈액형 = "Rh+A";
		boolean 결혼여부 = false;

		System.out.println("이름 :" + 이름);
		System.out.println("전화번호 :" + 전화번호);
		System.out.println("이메일 :" + 이메일);
		System.out.println("나이 :" + 나이);
		System.out.println("키 :" + 키);
		System.out.println("몸무게 :" + 몸무게);
		System.out.println("혈액형 :" + 혈액형);
		System.out.println("결혼여부 :" + 결혼여부);
	
	}

}
