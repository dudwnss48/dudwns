package datatype;

public class DataTypeDemo2 {
	
	public static void main(String[] args) {
		
		//변수의 선언과 초기화
		//자료형 식별자 =값;
		
		//int타입의 변수(저장소)를 만들고, 80을 대입한다.

		int kor = 80;
		int math = 70;
		int eng = 70;
		
		//변수의 사용
		System.out.println(kor+math+eng);
		System.out.println((kor+math+eng)/3);
	}

}
