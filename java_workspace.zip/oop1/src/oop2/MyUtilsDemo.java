package oop2;

public class MyUtilsDemo {
	
	public static void main(String[] args) {
		
		String text = MyUtills.numberWithcomma(1000000);
		System.out.println(text);
	}

}
