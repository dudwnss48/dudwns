package oop2;

public class GugudanDemo {
	
	public static void main(String[] args) {
		
		Gugudan gugudan = new Gugudan();
		
		gugudan.print99dan();
		System.out.println();
	
		gugudan.print99danByNumber(5);
		System.out.println();
		gugudan.print99danByNumber(19);
		System.out.println();
		
		gugudan.print99danByRnage(5, 10);
		System.out.println();


	}

}
