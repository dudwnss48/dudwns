package oop2;

public class Calculator {
	
	int plus(int x, int y) {
		int result = x+y;
		return result;
	}
	
	int plus(int x, int y,int z) {
		int result = x+y+z;
		return result;
	}
		
	double plus(double x, double y) {
		double result = x+y;
		return result;
	}
	long plus(long x, long y) {
		long result = x+y;
		return result;
	}
	
	long plus(long x, long y,long z) {
		long result = x+y+z;
		return result;
	}
	

}
