package oop2;

public class MethodDemo {
	
	

}
