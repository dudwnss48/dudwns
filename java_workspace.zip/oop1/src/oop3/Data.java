package oop3;

public class Data {
	
	int num;

}
