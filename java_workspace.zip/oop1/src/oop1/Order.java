package oop1;

public class Order {
	
	String name;
	String grade;
	int price;
	int point;
	String gift;
	
	
}
