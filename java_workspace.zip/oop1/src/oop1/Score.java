package oop1;

public class Score {
	
	String studentName;
	int kor;
	int eng;
	int math;
	int total;
	int average;
	boolean isPassed;
	

}
