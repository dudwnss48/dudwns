package oop1;

public class Account {
	
	// 클래스 변수 - 상수
	static final double RATE_OF_INTEREST = 0.021;
	
	
	
	// 인스턴스 변수
	String owner;		// 예금주
	String no;			
	String password;
	int balance;
	int period;
}
