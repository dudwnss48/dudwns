package oop1;

public class Person {
	
	// 맴버변수 정의하기 -> 객체의 속성이 된다.
	String name;
	String tel;
	String email;
	String gender;
	int age;
	
}
