package oop1;

public class Extends {
	
	public Extends() {
		// TODO Auto-generated constructor stub
	}

}
